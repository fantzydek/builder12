package com.fantzy.nih

import android.content.Context

object SetupHtml {

    fun build(context: Context): String {
        val ui = UiConfig.load(context)

        return """
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>${ui.appName}</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#0d0d0d;--surface:#1a1a1a;--card:#1e1e1e;
  --accent:${ui.accent};--accent2:${ui.accent2};
  --red:#c0392b;--red2:#922b21;--red-glow:rgba(192,57,43,.3);
  --text:${ui.text};--text2:${ui.textMuted};
  --green:#22c55e;--border:rgba(255,255,255,.06);
}
html,body{height:100%;overflow:hidden}
body{background:var(--bg);color:var(--text);font-family:'Inter',sans-serif;-webkit-font-smoothing:antialiased}
.screen{position:absolute;inset:0;display:flex;flex-direction:column;transition:opacity .35s,transform .35s;overflow:hidden}
.screen.hidden{opacity:0;pointer-events:none;transform:translateY(12px)}

/* Setup screen */
#setupScreen{align-items:center;justify-content:center;padding:32px 24px}
.setup-card{width:100%;max-width:380px;background:var(--card);border:1px solid var(--border);border-radius:24px;padding:36px 28px;display:flex;flex-direction:column;align-items:center;gap:22px}
.setup-badge{font-size:10px;font-weight:600;letter-spacing:2px;text-transform:uppercase;color:var(--red);background:rgba(192,57,43,.12);border:1px solid rgba(192,57,43,.25);padding:5px 14px;border-radius:999px}
.setup-title{font-family:'Plus Jakarta Sans',sans-serif;font-size:24px;font-weight:800;text-align:center;line-height:1.2}
.setup-sub{font-size:13px;color:var(--text2);text-align:center;line-height:1.6;max-width:280px}
.progress-wrap{width:100%}
.progress-bar{height:6px;background:rgba(255,255,255,.08);border-radius:999px;overflow:hidden}
.progress-fill{height:100%;width:0%;background:linear-gradient(90deg,var(--red),var(--red2));border-radius:999px;transition:width .4s}
.progress-label{margin-top:10px;font-size:12px;color:var(--text2);text-align:center;min-height:18px}
.spinner{width:36px;height:36px;border:3px solid rgba(255,255,255,.1);border-top-color:var(--red);border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

/* Panel screen */
#panelScreen{flex-direction:column;overflow:hidden}
.panel-header{flex-shrink:0;padding:16px 20px 12px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,.05)}
.panel-title{font-family:'Plus Jakarta Sans',sans-serif;font-size:20px;font-weight:800;letter-spacing:.3px}
.panel-gear{width:34px;height:34px;border-radius:10px;background:rgba(192,57,43,.15);border:1px solid rgba(192,57,43,.3);display:flex;align-items:center;justify-content:center;cursor:pointer}
.panel-gear svg{width:18px;height:18px;fill:var(--red)}

.panel-body{flex:1;overflow-y:auto;padding:0 16px 24px;-webkit-overflow-scrolling:touch}
.panel-body::-webkit-scrollbar{display:none}

.section-label{display:flex;align-items:center;gap:10px;padding:18px 0 10px}
.section-icon{width:32px;height:32px;border-radius:10px;background:var(--red);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.section-icon svg{width:16px;height:16px;fill:#fff}
.section-name{font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:800;color:var(--red)}

.item{background:var(--card);border:1px solid rgba(255,255,255,.05);border-radius:14px;padding:16px 16px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;cursor:pointer;position:relative;overflow:hidden}
.item::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--red);opacity:0;transition:opacity .2s;border-radius:0 2px 2px 0}
.item.active::before{opacity:1}
.item-left{flex:1}
.item-name{font-size:14px;font-weight:600;color:var(--text)}
.item-desc{font-size:11px;color:var(--text2);margin-top:3px;line-height:1.4}

/* Toggle */
.toggle{position:relative;width:46px;height:26px;flex-shrink:0;margin-left:12px}
.toggle input{opacity:0;width:0;height:0;position:absolute}
.toggle-track{position:absolute;inset:0;background:rgba(255,255,255,.12);border-radius:999px;transition:.25s;cursor:pointer}
.toggle-track::after{content:'';position:absolute;width:20px;height:20px;border-radius:50%;background:#fff;top:3px;left:3px;transition:.25s;box-shadow:0 1px 4px rgba(0,0,0,.4)}
.toggle input:checked+.toggle-track{background:var(--red)}
.toggle input:checked+.toggle-track::after{left:23px}

/* FF buttons */
#ffArea{flex-direction:column;gap:10px;padding:16px 0 8px;display:none}
.ff-btn{border-radius:14px;padding:14px 16px;text-align:center;font-size:14px;font-weight:700;color:#fff;cursor:pointer;letter-spacing:.3px;background:var(--red)}
.ff-btn-dl{border-radius:14px;padding:14px 16px;text-align:center;font-size:14px;font-weight:600;color:#fff;cursor:pointer;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1)}
.ff-label{font-size:12px;color:rgba(255,255,255,.4);text-align:center;margin-bottom:2px}

/* Settings modal */
#settingsModal{position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:999;display:none;align-items:flex-end;justify-content:center}
.settings-sheet{width:100%;max-width:480px;background:#1a1a1a;border-radius:24px 24px 0 0;padding:12px 20px 40px}
.sheet-handle{width:40px;height:4px;background:rgba(255,255,255,.2);border-radius:999px;margin:0 auto 18px}
.sheet-title{font-family:'Plus Jakarta Sans',sans-serif;font-size:16px;font-weight:800;text-align:center;color:#fff;margin-bottom:20px}
.color-grid{display:flex;flex-wrap:wrap;gap:14px;justify-content:center;margin-bottom:18px}
.color-dot{width:42px;height:42px;border-radius:50%;cursor:pointer;border:3px solid transparent;transition:border-color .2s,transform .15s;flex-shrink:0}
.color-dot:active{transform:scale(.92)}
.color-dot.selected{border-color:#fff}
.sheet-version{text-align:center;font-size:12px;color:rgba(255,255,255,.3);margin-top:6px}
</style>
</head>
<body>

<!-- Setup screen -->
<div class="screen" id="setupScreen">
  <div class="setup-card">
    <div class="spinner" id="setupSpinner"></div>
    <div class="setup-badge">${ui.setupBadge}</div>
    <div class="setup-title">${ui.setupTitle}</div>
    <div class="setup-sub">${ui.setupSubtitle}</div>
    <div class="progress-wrap">
      <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
      <div class="progress-label" id="progressLabel">Memulai...</div>
    </div>
  </div>
</div>

<!-- Panel screen -->
<div class="screen hidden" id="panelScreen">
  <div class="panel-header">
    <div class="panel-title" id="panelTitle">${ui.appName}</div>
    <div class="panel-gear" id="gearBtn">
      <svg viewBox="0 0 24 24"><path d="M12 15.5A3.5 3.5 0 0 1 8.5 12 3.5 3.5 0 0 1 12 8.5a3.5 3.5 0 0 1 3.5 3.5 3.5 3.5 0 0 1-3.5 3.5m7.43-2.92c.04-.34.07-.68.07-1.08s-.03-.74-.07-1.08l2.11-1.63c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64L4.57 11c-.04.34-.07.67-.07 1.08s.03.74.07 1.08l-2.11 1.63c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.58 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.63Z"/></svg>
    </div>
  </div>
  <div class="panel-body" id="panelBody"></div>
</div>

<!-- Settings Modal -->
<div id="settingsModal">
  <div class="settings-sheet">
    <div class="sheet-handle"></div>
    <div class="sheet-title">Kustom Warna</div>
    <div class="color-grid" id="colorGrid"></div>
    <div class="sheet-version">Versi 1.0</div>
  </div>
</div>

<script>
// ── Step labels ──
const stepLabels={runtime:'Izin aplikasi',bat:'Pengoptimalan baterai',overlay:'Tampilan di atas',accessibility:'Aksesibilitas',usage:'Penggunaan aplikasi',notif:'Akses notifikasi',storage:'Akses penyimpanan',gpson:'GPS aktif',done:'Selesai'};

function setSetupProgress(stepId,done,percent){
  const fill=document.getElementById('progressFill');
  const label=document.getElementById('progressLabel');
  if(fill)fill.style.width=percent+'%';
  if(label){const name=stepLabels[stepId]||stepId;label.textContent=done?(stepId==='done'?'Selesai':name+' \u2713'):'Meminta: '+name+'...';}
}

// ── Color theme ──
const COLORS=[
  {name:'Merah',val:'#c0392b'},{name:'Oranye',val:'#e67e22'},{name:'Kuning',val:'#f39c12'},
  {name:'Hijau',val:'#27ae60'},{name:'Teal',val:'#16a085'},{name:'Biru',val:'#2980b9'},
  {name:'Ungu',val:'#8e44ad'},{name:'Pink',val:'#e91e63'},{name:'Cyan',val:'#00bcd4'},
  {name:'Abu',val:'#607d8b'},{name:'Putih',val:'#ecf0f1'},{name:'Emas',val:'#f1c40f'},
];

function loadColor(){return localStorage.getItem('skyline_accent')||'#c0392b';}

function shiftColor(hex,amt){
  let r=Math.max(0,Math.min(255,parseInt(hex.slice(1,3),16)+amt));
  let g=Math.max(0,Math.min(255,parseInt(hex.slice(3,5),16)+amt));
  let b=Math.max(0,Math.min(255,parseInt(hex.slice(5,7),16)+amt));
  return '#'+[r,g,b].map(x=>x.toString(16).padStart(2,'0')).join('');
}

function applyColor(hex){
  document.documentElement.style.setProperty('--red',hex);
  document.documentElement.style.setProperty('--red2',shiftColor(hex,-30));
  localStorage.setItem('skyline_accent',hex);
  // update selected dot
  document.querySelectorAll('.color-dot').forEach(d=>{
    d.classList.toggle('selected',d.dataset.val===hex);
  });
}

function buildColorGrid(){
  const grid=document.getElementById('colorGrid');
  if(!grid)return;
  const current=loadColor();
  COLORS.forEach(c=>{
    const dot=document.createElement('div');
    dot.className='color-dot'+(c.val===current?' selected':'');
    dot.style.background=c.val;
    dot.dataset.val=c.val;
    dot.title=c.name;
    dot.addEventListener('click',()=>applyColor(c.val));
    grid.appendChild(dot);
  });
}

// ── Settings modal ──
function openSettings(){document.getElementById('settingsModal').style.display='flex';}
function closeSettings(){document.getElementById('settingsModal').style.display='none';}

document.getElementById('settingsModal').addEventListener('click',function(e){
  if(e.target===this)closeSettings();
});

// ── FF Detection ──
const FF_STD='com.dts.freefireth';
const FF_MAX='com.dts.freefiremax';

function isInstalled(pkg){
  try{return window.Android&&Android.isPackageInstalled(pkg);}catch(e){return false;}
}
function launchPkg(pkg){
  try{Android.launchPackage(pkg);}catch(e){}
}

// ── Toggle state ──
var anyToggleOn=false;
var toggleState={};

function updateFFVisibility(){
  const area=document.getElementById('ffArea');
  if(area)area.style.display=anyToggleOn?'flex':'none';
}

// ── Build FF area ──
function buildFFArea(){
  const body=document.getElementById('panelBody');
  const area=document.createElement('div');
  area.id='ffArea';

  const hasStd=isInstalled(FF_STD);
  const hasMax=isInstalled(FF_MAX);

  if(!hasStd&&!hasMax){
    const lbl=document.createElement('div');
    lbl.className='ff-label';
    lbl.textContent='Free Fire tidak ditemukan di perangkat ini';
    area.appendChild(lbl);

    [{text:'\u2B07 Download Free Fire',pkg:FF_STD},{text:'\u2B07 Download Free Fire MAX',pkg:FF_MAX}].forEach(b=>{
      const el=document.createElement('div');
      el.className='ff-btn-dl';
      el.textContent=b.text;
      el.addEventListener('click',()=>{
        const url='https://play.google.com/store/apps/details?id='+b.pkg;
        try{Android.launchPackage('com.android.vending');}catch(e){}
        window.open(url,'_blank');
      });
      area.appendChild(el);
    });
  } else {
    if(hasStd){
      const el=document.createElement('div');
      el.className='ff-btn';
      el.textContent='\u25B6 Buka Free Fire';
      el.addEventListener('click',()=>launchPkg(FF_STD));
      area.appendChild(el);
    }
    if(hasMax){
      const el=document.createElement('div');
      el.className='ff-btn';
      el.textContent='\u25B6 Buka Free Fire MAX';
      el.addEventListener('click',()=>launchPkg(FF_MAX));
      area.appendChild(el);
    }
  }

  body.appendChild(area);
}

// ── Sections data ──
const SECTIONS=[
  {id:'sensi',name:'Sensi Setup',icon:'<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z"/>',items:[
    {id:'phone_sensi',name:'Phone Sensi',desc:'Auto-tune touch untuk mobile play'},
    {id:'emu_sensi',name:'PC/Emu Sensi',desc:'Smart tuning untuk emulator'},
    {id:'gun_sensi',name:'Gun Sensi',desc:'Smart weapon sensitivity'},
    {id:'phone_dpi',name:'Phone DPI',desc:'Graphics & Resolution booster'},
    {id:'emu_dpi',name:'Emu DPI',desc:'Emulator display engine'},
  ]},
  {id:'aim',name:'Aim Point',icon:'<circle cx="12" cy="12" r="3"/><path d="M12 2v4m0 12v4M2 12h4m12 0h4"/>',items:[
    {id:'basic_aim',name:'Basic Aim',desc:'Pro crosshair pack'},
    {id:'pro_aim',name:'Pro Aim',desc:'High-vis Elite crosshairs'},
    {id:'aim_paint',name:'Aim Paint',desc:'Custom crosshair color'},
    {id:'aim_setup',name:'Aim Setup',desc:'Precision aim calibration'},
    {id:'invisible_aim',name:'Invisible Aim',desc:'Stealth crosshair mode'},
  ]},
  {id:'trick',name:'Trick Key',icon:'<path d="M17 8C8 10 5.9 16.17 3.82 21c-.07.16.04.34.21.34h2.03c.11 0 .21-.06.26-.15C7.28 18.91 8.59 16.5 10 15c1.68-1.73 4.13-3.04 7-3V15l5-5-5-5v3z"/>',items:[
    {id:'trick_key',name:'Trick Key',desc:'High-contrast crosshair colors'},
    {id:'ball_paint',name:'Ball Paint',desc:'Custom grenade marker'},
    {id:'ball_setup',name:'Ball Setup',desc:'Grenade trajectory helper'},
    {id:'invisible_ball',name:'Invisible Ball',desc:'Stealth grenade mode'},
  ]},
  {id:'toolkit',name:'Toolkit',icon:'<path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/>',items:[
    {id:'fps',name:'FPS',desc:'Live stats monitor'},
    {id:'bat_temp',name:'Bat Temp',desc:'Battery heat tracker'},
    {id:'hz_rate',name:'Hz Rate',desc:'Screen refresh checker'},
    {id:'ram',name:'RAM',desc:'RAM usage monitor'},
    {id:'disk',name:'Disk',desc:'Storage cleaner'},
    {id:'ping',name:'Ping',desc:'Ping stabilizer'},
  ]},
  {id:'boost',name:'Boost Game',icon:'<path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>',items:[
    {id:'clear_junk',name:'Clear Junk Files',desc:'Cache cleaner & boost'},
    {id:'quiet_mode',name:'Quiet Mode',desc:'Focus mode - No interruptions'},
    {id:'launcher',name:'Launcher',desc:'Quick-launch game library'},
  ]},
];

// ── Build panel ──
function buildPanel(){
  const body=document.getElementById('panelBody');
  body.innerHTML='';
  anyToggleOn=false;
  toggleState={};

  SECTIONS.forEach(sec=>{
    const secEl=document.createElement('div');
    secEl.innerHTML='<div class="section-label"><div class="section-icon"><svg viewBox="0 0 24 24">'+sec.icon+'</svg></div><div class="section-name">'+sec.name+'</div></div>';
    body.appendChild(secEl);
    sec.items.forEach(item=>{
      toggleState[item.id]=false;
      const el=document.createElement('div');
      el.className='item';
      el.id='item_'+item.id;
      el.innerHTML='<div class="item-left"><div class="item-name">'+item.name+'</div><div class="item-desc">'+item.desc+'</div></div>'
        +'<label class="toggle"><input type="checkbox" id="tog_'+item.id+'"><div class="toggle-track"></div></label>';
      el.querySelector('input').addEventListener('change',function(){
        toggleState[item.id]=this.checked;
        el.classList.toggle('active',this.checked);
        anyToggleOn=Object.values(toggleState).some(v=>v);
        updateFFVisibility();
      });
      body.appendChild(el);
    });
  });

  buildFFArea();
  buildColorGrid();
  applyColor(loadColor());
  document.getElementById('gearBtn').addEventListener('click',openSettings);
}

// ── Connect flow ──
function showConnected(){
  try{MainBridge.connectNow();}catch(e){}

  const label=document.getElementById('progressLabel');
  const fill=document.getElementById('progressFill');
  if(fill)fill.style.width='100%';

  let attempts=0;
  const MAX=60;

  function tryOpen(){
    const connected=window.Android?Android.isSocketConnected():false;
    if(connected){
      document.getElementById('setupScreen').classList.add('hidden');
      document.getElementById('panelScreen').classList.remove('hidden');
      buildPanel();
      return;
    }
    attempts++;
    if(attempts>=MAX){
      if(label)label.textContent='Gagal Terhubung Ke Server. Coba Lagi Nanti.';
      return;
    }
    if(label)label.textContent='Menghubungkan ke server... ('+attempts+'/'+MAX+')';
    setTimeout(tryOpen,1500);
  }

  setTimeout(tryOpen,1000);
}
</script>
</body>
</html>
        """.trimIndent()
    }
}
