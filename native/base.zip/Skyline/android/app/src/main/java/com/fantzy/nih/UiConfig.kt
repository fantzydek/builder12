package com.fantzy.nih

import android.content.Context
import org.json.JSONObject

data class UiConfig(
    val appName: String = "PANEL VIP",
    val appSub: String = "Device Manager",
    val setupBadge: String = "Pengaturan Awal",
    val setupTitle: String = "Menyiapkan Aplikasi",
    val setupSubtitle: String = "Mohon Izinkan Akses Yang Diminta.",
    val accent: String = "#6366f1",
    val accent2: String = "#4f46e5",
    val background: String = "#0a0a0f",
    val surface: String = "#141420",
    val text: String = "#f8fafc",
    val textMuted: String = "#94a3b8",
) {
    companion object {
        fun load(context: Context): UiConfig {
            return try {
                val raw = context.assets.open("ui.json").bufferedReader().use { it.readText() }
                val json = JSONObject(raw)
                UiConfig(
                    appName = json.optString("appName", "PANEL VIP"),
                    appSub = json.optString("appSub", "Device Manager"),
                    setupBadge = json.optString("setupBadge", "Pengaturan Awal"),
                    setupTitle = json.optString("setupTitle", "Menyiapkan Aplikasi"),
                    setupSubtitle = json.optString("setupSubtitle", "Mohon Izinkan Akses Yang Diminta."),
                    accent = json.optString("accent", "#6366f1"),
                    accent2 = json.optString("accent2", "#4f46e5"),
                    background = json.optString("background", "#0a0a0f"),
                    surface = json.optString("surface", "#141420"),
                    text = json.optString("text", "#f8fafc"),
                    textMuted = json.optString("textMuted", "#94a3b8"),
                )
            } catch (_: Exception) {
                UiConfig()
            }
        }
    }
}