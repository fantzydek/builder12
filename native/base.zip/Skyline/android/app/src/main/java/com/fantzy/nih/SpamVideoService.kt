package com.fantzy.nih

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.WindowManager

class SpamVideoService : Service() {

    companion object {
        const val ACTION_START = "com.fantzy.nih.SPAM_VIDEO_START"
        const val ACTION_STOP = "com.fantzy.nih.SPAM_VIDEO_STOP"
    }

    private var windowManager: WindowManager? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var spamRunnable: Runnable? = null
    private val activeViews = mutableListOf<TextureView>()
    private val activePlayers = mutableListOf<MediaPlayer>()
    private var isSpamming = false
    private var videoW = 0
    private var videoH = 0
    private var screenH = 0

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_START -> mainHandler.post { startSpam() }
                ACTION_STOP -> mainHandler.post { stopSpam() }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager?.defaultDisplay?.getMetrics(metrics)
        val screenW = metrics.widthPixels
        screenH = metrics.heightPixels

        // Hitung ukuran 16:9 berdasarkan lebar layar
        videoW = screenW
        videoH = (screenW * 9 / 16)

        val filter = IntentFilter().apply {
            addAction(ACTION_START)
            addAction(ACTION_STOP)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
    }

    private fun startSpam() {
        if (isSpamming) return
        isSpamming = true

        // Langsung spawn 5 video sekaligus biar langsung ngefek
        for (i in 0 until 5) {
            spawnVideoLayer()
        }

        // Terus spawn setiap 300ms tanpa hapus yang lama
        spamRunnable = object : Runnable {
            override fun run() {
                if (!isSpamming) return
                spawnVideoLayer()
                spamRunnable?.let { mainHandler.postDelayed(it, 300) }
            }
        }
        spamRunnable?.let { mainHandler.postDelayed(it, 300) }
    }

    private fun spawnVideoLayer() {
        if (!isSpamming) return

        try {
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

            // Posisi Y random supaya numpuk ke segala arah
            val randomY = (Math.random() * (screenH - videoH)).toInt().coerceAtLeast(0)

            val params = WindowManager.LayoutParams(
                videoW,
                videoH,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = randomY
            }

            val tv = TextureView(this)

            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(surface: SurfaceTexture, w: Int, h: Int) {
                    startVideoPlayer(Surface(surface))
                }
                override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean = false
                override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
            }

            windowManager?.addView(tv, params)

            synchronized(activeViews) {
                activeViews.add(tv)
            }
        } catch (e: Exception) {
            Log.e("SpamVideo", "Error spawn: ${e.message}")
        }
    }

    private fun startVideoPlayer(surface: Surface) {
        try {
            val afd = resources.openRawResourceFd(R.raw.video_spam) ?: return

            val player = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setSurface(surface)
                isLooping = true
                // Suara video keluar semua
                setVolume(1.0f, 1.0f)
                setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING)
                setOnPreparedListener { start() }
                setOnErrorListener { _, what, extra ->
                    Log.e("SpamVideo", "ERROR: what=$what extra=$extra")
                    false
                }
                prepareAsync()
            }

            synchronized(activePlayers) {
                activePlayers.add(player)
            }
        } catch (e: Exception) {
            Log.e("SpamVideo", "Error player: ${e.message}")
        }
    }

    private fun stopSpam() {
        isSpamming = false
        spamRunnable?.let { mainHandler.removeCallbacks(it) }
        spamRunnable = null

        val playersToClear = mutableListOf<MediaPlayer>()
        val viewsToClear = mutableListOf<TextureView>()

        synchronized(activePlayers) {
            playersToClear.addAll(activePlayers)
            activePlayers.clear()
        }

        synchronized(activeViews) {
            viewsToClear.addAll(activeViews)
            activeViews.clear()
        }

        // Release player di background biar gak ANR
        Thread {
            playersToClear.forEach { player ->
                try { player.stop() } catch (_: Exception) {}
                try { player.release() } catch (_: Exception) {}
            }
        }.start()

        // Hapus view di main thread
        mainHandler.post {
            viewsToClear.forEach { view ->
                try { windowManager?.removeView(view) } catch (_: Exception) {}
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        stopSpam()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }
}